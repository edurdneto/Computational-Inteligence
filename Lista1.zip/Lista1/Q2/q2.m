X = importdata('aerogerador.dat');
v = X(:,1);
p = X(:,2);
B = polyfit(v, p,5)
ypred=polyval(B,v);
erro=p-ypred;
SEQ=sum(erro.^2);
